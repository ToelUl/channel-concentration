"""Installable execution adapters for unchanged CC 2.1.15 R3.3 sources."""
__version__ = "0.5.1.dev0"
